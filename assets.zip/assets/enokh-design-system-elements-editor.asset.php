<?php return array('dependencies' => array(), 'version' => '11a0bbe76fa50cb730ab');
