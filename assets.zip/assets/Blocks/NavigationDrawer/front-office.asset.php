<?php return array('dependencies' => array(), 'version' => '447826f5f07d04fcc920');
