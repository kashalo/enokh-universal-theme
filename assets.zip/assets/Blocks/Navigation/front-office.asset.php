<?php return array('dependencies' => array(), 'version' => 'b28800ef54d3abde92cb');
