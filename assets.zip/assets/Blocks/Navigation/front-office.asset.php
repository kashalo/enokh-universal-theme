<?php return array('dependencies' => array(), 'version' => 'fb77b8e69ebc529eccef');
