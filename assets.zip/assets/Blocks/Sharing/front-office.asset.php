<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'd9ea3b290b91105858fb');
