<?php return array('dependencies' => array(), 'version' => '65b13217be753c180955');
