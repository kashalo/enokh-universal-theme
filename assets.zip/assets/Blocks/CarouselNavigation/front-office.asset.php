<?php return array('dependencies' => array(), 'version' => '9304bae44935048c59e9');
