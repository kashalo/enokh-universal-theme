<?php return array('dependencies' => array(), 'version' => '1966faf0898c749a5a07');
