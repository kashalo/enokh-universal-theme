<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-primitives'), 'version' => 'b335ae243cfcb94a5459');
