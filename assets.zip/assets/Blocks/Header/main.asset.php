<?php return array('dependencies' => array(), 'version' => 'ad3e787815ee2e1279c1');
