<?php return array('dependencies' => array(), 'version' => 'fb08fee0efc6dfe90a32');
