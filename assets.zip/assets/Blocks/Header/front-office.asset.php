<?php return array('dependencies' => array(), 'version' => 'ad2a129e88a435c0cabc');
