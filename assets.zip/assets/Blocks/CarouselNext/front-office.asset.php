<?php return array('dependencies' => array(), 'version' => 'f96d2b5dfcd40f0c373f');
