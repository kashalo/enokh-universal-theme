<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '3d4aca277813a2102fc0');
