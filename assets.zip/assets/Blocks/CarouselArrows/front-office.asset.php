<?php return array('dependencies' => array(), 'version' => '3d3362af43e95d92a940');
