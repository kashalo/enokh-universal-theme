<?php return array('dependencies' => array(), 'version' => '319faff3898a884717f4');
