<?php return array('dependencies' => array(), 'version' => 'f7dc7dab10f02ac761a8');
