<?php return array('dependencies' => array(), 'version' => '55eb233190e56a886fea');
