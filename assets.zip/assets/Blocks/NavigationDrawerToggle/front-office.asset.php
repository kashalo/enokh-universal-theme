<?php return array('dependencies' => array(), 'version' => '6ca0b905e4c96ba57694');
