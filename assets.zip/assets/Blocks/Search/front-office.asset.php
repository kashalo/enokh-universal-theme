<?php return array('dependencies' => array(), 'version' => '05ede70a89e64eaedbc2');
