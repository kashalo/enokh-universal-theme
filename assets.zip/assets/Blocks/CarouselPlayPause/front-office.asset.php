<?php return array('dependencies' => array(), 'version' => 'f1298a97ec13b3670d60');
