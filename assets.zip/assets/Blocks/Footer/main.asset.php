<?php return array('dependencies' => array(), 'version' => 'c684ce0ca11dd0a1f896');
