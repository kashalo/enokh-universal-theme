<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-primitives'), 'version' => '057a030b7de7175b0db7');
