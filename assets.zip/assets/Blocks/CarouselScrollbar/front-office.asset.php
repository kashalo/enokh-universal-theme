<?php return array('dependencies' => array(), 'version' => '5e70a8a7e53f259c5e10');
