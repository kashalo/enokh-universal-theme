<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-primitives'), 'version' => '5b4680fe561ccbfe3f70');
