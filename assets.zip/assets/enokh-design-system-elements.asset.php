<?php return array('dependencies' => array(), 'version' => '84f671b5a0d06d5d0cc6');
