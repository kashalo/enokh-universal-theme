<?php return array('dependencies' => array('wp-blocks', 'wp-dom-ready'), 'version' => 'e04bdd3466b1c23231cd');
