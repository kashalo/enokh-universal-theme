<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '2e9fba43f4cfbe6a4541');
