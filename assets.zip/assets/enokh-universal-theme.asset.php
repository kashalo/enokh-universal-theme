<?php return array('dependencies' => array(), 'version' => '91e043271d32376412a0');
