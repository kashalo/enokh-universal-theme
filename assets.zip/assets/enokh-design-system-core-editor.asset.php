<?php return array('dependencies' => array(), 'version' => '382843753bca64df7da6');
